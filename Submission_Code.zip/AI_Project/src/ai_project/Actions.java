package ai_project;
// the Actions that the agent can perform
public enum Actions {
    moveLeft, moveRight, moveUp, moveDown, useDragonStone, pickDragonstone;
}
