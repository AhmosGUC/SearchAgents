package ai_project;
// The possible items a cell can have.
public enum Cell {
    empty, snow, ww, dragonstone, obstacle, SnowInStore,deadww;
}
